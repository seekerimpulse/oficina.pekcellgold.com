<div id="content">
	<div class="row">
		<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
			<h1 class="page-title txt-color-blueDark">
				
				<!-- PAGE HEADER -->
				<a href="/ov/dashboard"><i class="fa fa-home"></i> Inicio</a>
				<span>> 
					Menu Carrito
				</span>
			</h1>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12 col-xs-12 col-sm-12 col-lg-12">
			<div class="row">
				<div class="well">
					<fieldset>
						
						<div class="row">
							<div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
								<a href="carrito?tipo=1">
									<div class="well well-sm txt-color-white text-center link_dashboard" style="background:<?=$style[0]->btn_1_color?>;">
										<i class="fa fa-user fa-3x"></i>
										<h5>Compra Personal</h5>
									</div>
								</a>
							</div>
							<div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
								<a onclick="comprador()" style="cursor: pointer;">
									<div class="well well-sm txt-color-white text-center link_dashboard" style="background:<?=$style[0]->btn_2_color?>">
										<i class="fa fa-group fa-3x"></i>
										<h5>Compra por otra persona</h5>
									</div>     
								</a>
							</div>
							<div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
								<a href="carrito?tipo=3">
									<div class="well well-sm txt-color-white text-center link_dashboard" style="background:<?=$style[0]->btn_1_color?>;">
										<i class="fa fa-clock-o fa-3x"></i>
										<h5>Compra Autom&aacute;tica</h5>
									</div>
								</a>
							</div>
						</div>
					</fieldset>
				</div>
			</div>
		</div>
	</div>

</div>	
<script>
	function comprador()
	{
		$.ajax({
			type: "get",
			url: "select_af",
			success: function(msg){
				bootbox.dialog({
						message: msg,
						title: "Selecciona un afiliado",
						className: "",
				});
			}
		});
	}
	function enviar_carro()
	{
		if($("#afiliado_id").val()==0)
		{
			alert("Selecciona un afiliado");
		}
		else
		{
			var afiliado=$("#afiliado_id").val();
			if (confirm('¿Seguro que desea realizar una compra para este afiliado?')) {
			    window.location.assign("carrito?tipo=2&usr="+afiliado)
			} else {
			    // Do nothing!
			}
		}
	}
</script>