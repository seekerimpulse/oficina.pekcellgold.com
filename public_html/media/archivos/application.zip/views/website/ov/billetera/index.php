 <!-- MAIN CONTENT -->
<div id="content">
	<div class="row">
		<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
			<h1 class="page-title txt-color-blueDark">
					<a href="/ov"><i class="fa fa-home"></i> Menu</a>
				<span>> Billetera
				</span>
			</h1>
		</div>
	</div>
<section id="widget-grid" class="">
<div class="row" style="background: rgb(255, 255, 255) none repeat scroll 0% 0%;margin-bottom:2rem;">	
	<div class="well">
			<fieldset>
				
					<div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
						<a href="estado">
							<div class="well well-sm txt-color-white text-center link_dashboard" style="background:#60a917">
								<i class="fa fa-signal fa-3x"></i>
								<h5>Estado de Cuenta</h5>
							</div>	
						</a>
					</div>
					<div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
						<a href="/ov/billetera2/historial">
							<div class="well well-sm txt-color-white text-center link_dashboard" style="background:#60a917">
								<i class="fa fa-calendar fa-3x"></i>
								<h5>Historial</h5>
							</div>	
						</a>
					</div>
					
					<div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
						<a href="pedir_pago">
							<div class="well well-sm txt-color-white text-center link_dashboard" style="background:#60a917">
								<i class="fa fa-money fa-3x"></i>
								<h5>Pedir Plata</h5> 
							</div>	
						</a>
					</div>
			</fieldset>
		</div>
	</div>
</section>	
</div>	