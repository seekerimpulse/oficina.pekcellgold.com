<!DOCTYPE html>
	<html>
		<head><title>Información</title></head>
		<body>
			<main>
				<div style="font-size-adjust: verdena; padding: 250px; border-radius:25px; border:25px; background-color: AliceBlue;">
				<div style="font-size-adjust: verdena; padding: 150px; border-radius:20px; border:20px; background-color: Gainsboro;">	
		<blockquote><h1 style="font-size: 200px/100px Arial, Helvetica, sans-serif; margin: 0; padding: 0 0 18px; color: black;"><div id="container" styale="width:1000px">SELECT.</h1>
<form action="">
	
				<select name="general">
					<option value="Direccion General">Direccion General</option>
					<option value="Direccion Comercial">Direccion Comercial</option>
					<option value="Soporte Tecnico">Soporte Tecnico</option><br>
			</select><br>
				<form action="">	
				<strong><style="text-aling:left;">Nombre:</style></strong><input type="text" name="NOMBRE"></br>
				<strong><style="text-aling:right">E-mail</style></strong><input type="text" name="E-MIAL"></br>
				<strong><style="text-aling:left;">Telefono:</style></strong><input type="text" name="TELEFONO"></br>
				<strong><style="text-aling:right">Comentario:</style></strong><textarea rows="10" cols="15" type="text" name"COMENTARIO"></textarea></br>
				<button type="button" onclick="Enviar()">Enviar</button>
				</blockquote>	
			</form>
		</div>
		</div>
		</main>
			</body>
			</html>	