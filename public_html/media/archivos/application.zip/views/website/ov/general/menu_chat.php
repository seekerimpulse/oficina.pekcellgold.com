<div id="content">
	<div class="row">
		<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
			<h1 class="page-title txt-color-blueDark">
				
				<!-- PAGE HEADER -->
				<a href="/ov/dashboard"><i class="fa fa-home"></i> Inicio</a>
				<span>> 
					Menu chat
				</span>
			</h1>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12 col-xs-12 col-sm-12 col-lg-12">
			<div class="row">
				<div class="well">
					<fieldset>
						
						<div class="row">
							<div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">
							</div>
							<div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
								<a href="chat_red">
									<div class="well well-sm txt-color-white text-center link_dashboard" style="background:<?=$style[0]->btn_1_color?>;">
										<i class="fa fa-user fa-3x"></i>
										<h5>Chat con mi red</h5>
									</div>
								</a>
							</div>
							<div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
								<a href="chat_social">
									<div class="well well-sm txt-color-white text-center link_dashboard" style="background:<?=$style[0]->btn_2_color?>">
										<i class="fa fa-group fa-3x"></i>
										<h5>Chat con redes sociales</h5>
									</div>     
								</a>
							</div>
						</div>
					</fieldset>
				</div>
			</div>
		</div>
	</div>
</div>