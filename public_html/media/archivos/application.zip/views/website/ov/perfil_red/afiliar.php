
<!-- MAIN CONTENT -->
<div id="content">
	<div class="row">
		<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
			<h1 class="page-title txt-color-blueDark">
					<a href="/ov/dashboard"><i class="fa fa-home"></i> Inicio</a>
				<span> 
				> <a href="/ov/perfil_red/afiliar">Redes</a>
				> Afiliar
				</span>
			</h1>
		</div>
	</div>
	<section id="widget-grid" class="">
		<div class="row"
			style="background: rgb(255, 255, 255) none repeat scroll 0% 0%; margin-bottom: 2rem;">
			<div class="well">
				<fieldset>
					<legend>Red</legend>
					<div class="row">
						<div class="col-lg-1 col-sm-1 col-md-1 col-xs-12"></div>
						<div class="col-lg-5 col-sm-5 col-md-5 col-xs-12">
							<a href="/ov/perfil_red/afiliar_frontal?id=<?php echo $_GET['id']; ?>">
								<div
									class="well well-sm txt-color-white text-center link_dashboard"
									style="background: #60a917">
									<i class="fa fa-sitemap fa-3x"></i>
									<h5>Afiliar en Frontal</h5>
								</div>
							</a>
						</div>
						<div class="col-lg-5 col-sm-5 col-md-5 col-xs-12">
							<a href="/ov/perfil_red/afiliar_red?id=<?php echo $_GET['id']; ?>">
								<div
									class="well well-sm txt-color-white text-center link_dashboard"
									style="background: #60a917">
									<i class="fa fa-sitemap fa-3x"></i>
									<h5>Afiliar en Red</h5>
								</div>
							</a>
						</div>
					</div>
				</fieldset>
			</div>
		</div>
	</section>
</div>
